﻿using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace IFCViewer
{
    /// <summary>
    /// Renderer.
    /// </summary>
    interface IIFCRenderer : IDisposable
    {
        /// <summary>
        /// Accessor
        /// </summary>
        IIFCViewer Viewer
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool ShowFaces
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool ShowWireframes
        {
            get;
            set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        bool SelectOnMouseHover
        {
            get;
            set;
        }

        /// <summary>
        /// Resets the scene
        /// </summary>
        void Reset();

        /// <summary>
        /// Repaints the image
        /// </summary>
        void Redraw();

        /// <summary>
        /// An IFC item has been selected
        /// </summary>
        /// <param name="ifcItem"></param>
        void OnSelect(IFCItem ifcItem);

        /// <summary>
        /// Saves the image as a file
        /// </summary>
        void SaveToFile(string strFile, ImageFileFormat imageFileFormat);
    }
}
