﻿using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using System.Xml;

namespace IFCViewer
{
    /// <summary>
    /// Main form
    /// </summary>
    public partial class MainForm : Form
    {
        #region Members

        /// <summary>
        /// IFC Model
        /// </summary>
        IFCModel _model = null;

        /// <summary>
        /// IFC Renderer
        /// </summary>
        IIFCRenderer _renderer = null;

        /// <summary>
        /// IFC Viewer
        /// </summary>
        IIFCViewer _viewer = null;

        #endregion // Members

        /// <summary>
        /// ctor
        /// </summary>
        public MainForm()
        {
            this.SetStyle(ControlStyles.AllPaintingInWmPaint, true);
            this.SetStyle(ControlStyles.UserPaint, true);          

            InitializeComponent();
            
            /*
             * Model
             */
            _model = new IFCModel();

            /*
             * Viewer
             */
            _viewer = new TreeIFCViewer(_model, _treeView);

            /*
             * Renderer
             */
            _renderer = new SharpDXRenderer(_model, this.splitContainer.Panel2);

            _viewer.Renderer = _renderer;
            _renderer.Viewer = _viewer;
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void openToolStripMenuItem_Click(object sender, EventArgs e)
        {
            OpenFileDialog dialog = new OpenFileDialog();
            dialog.Filter = "IFC files (*.ifc)|*.ifc";
            dialog.Title = "Open";

            if (dialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            if (_model.Load(dialog.FileName))
            {
                this.Text = string.Format("{0} - IFCViewer", System.IO.Path.GetFileNameWithoutExtension(dialog.FileName));
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void toolStripMenuSaveAs_Click(object sender, EventArgs e)
        {
            SaveFileDialog dialog = new SaveFileDialog();
            dialog.Filter = "JPG files (*.jpg)|*.jpg|PNG files (*.png)|*.png|BMP files (*.bmp)|*.bmp";
            dialog.Title = "Save as...";

            if (dialog.ShowDialog() != DialogResult.OK)
            {
                return;
            }

            _renderer.SaveToFile(dialog.FileName,
                dialog.FilterIndex == 1 ? ImageFileFormat.Jpg : dialog.FilterIndex == 2 ? ImageFileFormat.Png : ImageFileFormat.Bmp);
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void MainForm_Load(object sender, EventArgs e)
        {
            this.splitContainer.Panel2.BackColor = Color.Transparent;
            // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
            string IFC_NAME = "01-2021-A3-3-110kV配电装置楼-建筑.ifc";
            // string IFC_NAME = "2021-ZJ-110-A3-3(20211015).ifc";
            if (_model.Load(IFC_NAME))
            {
                IFC2XML(IFC_NAME);
            }
            // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
        }

        // 曹金浩于2023年04月03日于上海交通大学X57宿舍4021修改
        public static int COUNT = 0;
        // 曹金浩于2023年04月03日于上海交通大学X57宿舍4021修改

        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
        private void IFC2XML(string IFC_NAME)
        {
            XmlDocument DOCUMENT = new XmlDocument();
            XmlDeclaration DECLARATION = DOCUMENT.CreateXmlDeclaration("1.0", "utf-8", null);
            DOCUMENT.AppendChild(DECLARATION);
            XmlElement PARENT = DOCUMENT.CreateElement("", "IFC", "");
            DOCUMENT.AppendChild(PARENT);
            PARENT.SetAttribute("FileName", IFC_NAME);
            PARENT.SetAttribute("DateTime", DateTime.Now.ToString());
            foreach (TreeNode i in TreeIFCViewer._treeControl.Nodes)
            {
                if (i.Text == "Header Info")
                {
                    XmlElement CHILD = DOCUMENT.CreateElement("", "IFC", "");
                    PARENT.AppendChild(CHILD);
                    CHILD.SetAttribute("PartName", i.Text.Split(' ')[0]);
                    HEADER2XML(i, DOCUMENT, CHILD);
                }
                else if (i.Text == "Not Referenced")
                {
                    //XmlElement CHILD = DOCUMENT.CreateElement("", "IFC", "");
                    //PARENT.AppendChild(CHILD);
                    //CHILD.SetAttribute("PartName", i.Text);
                    //NOTREFERENCED2XML(i, DOCUMENT, CHILD);
                }
                else
                {
                    XmlElement CHILD = DOCUMENT.CreateElement("", "IFC", "");
                    PARENT.AppendChild(CHILD);
                    Regex REGEX = new Regex(@"\((\w+)\)");
                    Match MATCH = REGEX.Match(i.Text);
                    if (MATCH.Success)
                    {
                        CHILD.SetAttribute("PartName", MATCH.Groups[1].Value);
                        BODY2XML(i, DOCUMENT, CHILD);
                    }
                }
            }
            string XML_NAME = Path.GetFileNameWithoutExtension(IFC_NAME) + ".xml";
            DOCUMENT.Save(XML_NAME);
        }
        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改

        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
        private void BODY2XML(TreeNode i, XmlDocument DOCUMENT, XmlElement CHILD)
        {
            if (i.Text.Contains("IfcWallStandardCase") ||
                i.Text.Contains("IfcBuildingElementProxy") ||
                i.Text.Contains("IfcSlab") ||
                i.Text.Contains("IfcDoor") ||
                i.Text.Contains("IfcWindow") ||
                i.Text.Contains("IfcRoof"))
            {
                CHILD.SetAttribute("Min", IFCModel.DATA[COUNT].Split(';')[0]);
                CHILD.SetAttribute("Max", IFCModel.DATA[COUNT].Split(';')[1]);
                COUNT++;
            }
            foreach (TreeNode j in i.Nodes)
            {
                Regex REGEX = new Regex(@"'(.*)'.*'(.*)'.*\((\w+)\)");
                Match MATCH = REGEX.Match(j.Text);
                if (MATCH.Success)
                {
                    if (MATCH.Groups[3].Value == "IfcPropertySet")
                    {
                        foreach (TreeNode k in j.Nodes)
                        {
                            Regex REGEX1 = new Regex(@"'(.*)'.*'(.*)'.*\((\w+)\)");
                            Match MATCH1 = REGEX1.Match(k.Text);
                            if (MATCH1.Success)
                            {
                                CHILD.SetAttribute(MATCH1.Groups[1].Value.Replace(" ", "").Replace("(", "").Replace(")", ""), MATCH1.Groups[2].Value);
                            }
                        }
                    }
                    else
                    {
                        if (j.Nodes.Count != 0)
                        {
                            XmlElement CHILDCHILD = DOCUMENT.CreateElement("", "IFC", "");
                            CHILDCHILD.SetAttribute("PartName", MATCH.Groups[3].Value);
                            CHILDCHILD.SetAttribute("Description", MATCH.Groups[1].Value);
                            CHILD.AppendChild(CHILDCHILD);
                            BODY2XML(j, DOCUMENT, CHILDCHILD);
                        }
                    }
                }
            }
        }
        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改

        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
        private void NOTREFERENCED2XML(TreeNode i, XmlDocument DOCUMENT, XmlElement CHILD)
        {
            foreach (TreeNode j in i.Nodes)
            {
                XmlElement CHILDCHILD = DOCUMENT.CreateElement("", "IFC", "");
                CHILD.AppendChild(CHILDCHILD);
                Regex REGEX = new Regex(@"'(.*)'.*'(.*)'.*\((\w+)\)");
                Match MATCH = REGEX.Match(j.Text);
                if (MATCH.Success)
                {;
                    CHILDCHILD.SetAttribute("PartName", MATCH.Groups[3].Value);
                    CHILDCHILD.SetAttribute("Description", MATCH.Groups[1].Value);
                    CHILDCHILD.SetAttribute("Min", "0,0,0");
                    CHILDCHILD.SetAttribute("Max", "0,0,0");
                }
            }
        }
        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改

        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改
        private void HEADER2XML(TreeNode i, XmlDocument DOCUMENT, XmlElement CHILD)
        {
            foreach (TreeNode j in i.Nodes)
            {
                XmlElement CHILDCHILD = DOCUMENT.CreateElement("", "IFC", "");
                CHILD.AppendChild(CHILDCHILD);
                if (j.Text.Contains("="))
                {
                    string[] TEXT = j.Text.Replace(" ", "").Replace("'", "").Split('=');
                    CHILDCHILD.SetAttribute(TEXT[0], TEXT[1]);
                }
                else
                {
                    string TEXT = j.Text.Replace(" ", "");
                    string VALUE = "";
                    foreach (TreeNode k in j.Nodes)
                    {
                        VALUE = VALUE + k.Text + ",";
                    }
                    CHILDCHILD.SetAttribute(TEXT, VALUE.TrimEnd(','));
                }
            }
        }
        // 曹金浩于2023年04月02日于上海交通大学X57宿舍4021修改

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void resetToolStripMenuItem_Click(object sender, EventArgs e)
        {            
            _renderer.Reset();
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void viewFacesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (viewFacesToolStripMenuItem == sender)
            {
                _renderer.ShowFaces = viewFacesToolStripMenuItem.Checked;
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void viewWireFrameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (viewWireFrameToolStripMenuItem == sender)
            {
                _renderer.ShowWireframes = viewWireFrameToolStripMenuItem.Checked;
            }           
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void selectOnOverIn3DToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (selectOnOverIn3DToolStripMenuItem == sender)
            {
                _renderer.SelectOnMouseHover = selectOnOverIn3DToolStripMenuItem.Checked;
            }
        }

        /// <summary>
        /// Event handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void aboutIfcviewerToolStripMenuItem_Click(object sender, EventArgs e)
        {
            AboutBox aboutBox = new AboutBox();
            aboutBox.ShowDialog();            
        }

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }

            if (_renderer != null)
            {
                _renderer.Dispose();
            }

            base.Dispose(disposing);
        }
    }
}
