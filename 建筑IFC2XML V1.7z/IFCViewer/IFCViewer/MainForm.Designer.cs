﻿namespace IFCViewer
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.openToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuSaveAs = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewFacesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewWireFrameToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.resetToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.selectOnOverIn3DToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutIfcviewerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer = new System.Windows.Forms.SplitContainer();
            this._treeView = new System.Windows.Forms.TreeView();
            this.ilTreeIcons = new System.Windows.Forms.ImageList(this.components);
            this.menuStrip.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).BeginInit();
            this.splitContainer.Panel1.SuspendLayout();
            this.splitContainer.SuspendLayout();
            this.SuspendLayout();
            // 
            // statusStrip
            // 
            this.statusStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.statusStrip.Location = new System.Drawing.Point(0, 592);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Padding = new System.Windows.Forms.Padding(1, 0, 13, 0);
            this.statusStrip.Size = new System.Drawing.Size(752, 22);
            this.statusStrip.TabIndex = 0;
            this.statusStrip.Text = "statusStrip";
            // 
            // menuStrip
            // 
            this.menuStrip.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.menuStrip.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem,
            this.viewToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.Padding = new System.Windows.Forms.Padding(5, 2, 0, 2);
            this.menuStrip.Size = new System.Drawing.Size(752, 28);
            this.menuStrip.TabIndex = 2;
            this.menuStrip.Text = "menuStrip";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.openToolStripMenuItem,
            this.toolStripMenuSaveAs,
            this.toolStripSeparator1,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(48, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // openToolStripMenuItem
            // 
            this.openToolStripMenuItem.Name = "openToolStripMenuItem";
            this.openToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.openToolStripMenuItem.Text = "Open";
            this.openToolStripMenuItem.Click += new System.EventHandler(this.openToolStripMenuItem_Click);
            // 
            // toolStripMenuSaveAs
            // 
            this.toolStripMenuSaveAs.Name = "toolStripMenuSaveAs";
            this.toolStripMenuSaveAs.Size = new System.Drawing.Size(157, 26);
            this.toolStripMenuSaveAs.Text = "Save as...";
            this.toolStripMenuSaveAs.Click += new System.EventHandler(this.toolStripMenuSaveAs_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(154, 6);
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(157, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            this.exitToolStripMenuItem.Click += new System.EventHandler(this.exitToolStripMenuItem_Click);
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewFacesToolStripMenuItem,
            this.viewWireFrameToolStripMenuItem,
            this.toolStripSeparator2,
            this.resetToolStripMenuItem,
            this.toolStripSeparator3,
            this.selectOnOverIn3DToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(58, 24);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // viewFacesToolStripMenuItem
            // 
            this.viewFacesToolStripMenuItem.Checked = true;
            this.viewFacesToolStripMenuItem.CheckOnClick = true;
            this.viewFacesToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.viewFacesToolStripMenuItem.Name = "viewFacesToolStripMenuItem";
            this.viewFacesToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.viewFacesToolStripMenuItem.Text = "View Faces";
            this.viewFacesToolStripMenuItem.Click += new System.EventHandler(this.viewFacesToolStripMenuItem_Click);
            // 
            // viewWireFrameToolStripMenuItem
            // 
            this.viewWireFrameToolStripMenuItem.Checked = true;
            this.viewWireFrameToolStripMenuItem.CheckOnClick = true;
            this.viewWireFrameToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.viewWireFrameToolStripMenuItem.Name = "viewWireFrameToolStripMenuItem";
            this.viewWireFrameToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.viewWireFrameToolStripMenuItem.Text = "View Wireframes";
            this.viewWireFrameToolStripMenuItem.Click += new System.EventHandler(this.viewWireFrameToolStripMenuItem_Click);
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(237, 6);
            // 
            // resetToolStripMenuItem
            // 
            this.resetToolStripMenuItem.Name = "resetToolStripMenuItem";
            this.resetToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.resetToolStripMenuItem.Text = "Reset";
            this.resetToolStripMenuItem.Click += new System.EventHandler(this.resetToolStripMenuItem_Click);
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(237, 6);
            // 
            // selectOnOverIn3DToolStripMenuItem
            // 
            this.selectOnOverIn3DToolStripMenuItem.Checked = true;
            this.selectOnOverIn3DToolStripMenuItem.CheckOnClick = true;
            this.selectOnOverIn3DToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.selectOnOverIn3DToolStripMenuItem.Name = "selectOnOverIn3DToolStripMenuItem";
            this.selectOnOverIn3DToolStripMenuItem.Size = new System.Drawing.Size(240, 26);
            this.selectOnOverIn3DToolStripMenuItem.Text = "Select on Over in 3D";
            this.selectOnOverIn3DToolStripMenuItem.Click += new System.EventHandler(this.selectOnOverIn3DToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Checked = true;
            this.helpToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.aboutIfcviewerToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(58, 24);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // aboutIfcviewerToolStripMenuItem
            // 
            this.aboutIfcviewerToolStripMenuItem.Name = "aboutIfcviewerToolStripMenuItem";
            this.aboutIfcviewerToolStripMenuItem.Size = new System.Drawing.Size(226, 26);
            this.aboutIfcviewerToolStripMenuItem.Text = "About IFCViewer...";
            this.aboutIfcviewerToolStripMenuItem.Click += new System.EventHandler(this.aboutIfcviewerToolStripMenuItem_Click);
            // 
            // splitContainer
            // 
            this.splitContainer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.splitContainer.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer.Location = new System.Drawing.Point(0, 28);
            this.splitContainer.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.splitContainer.Name = "splitContainer";
            // 
            // splitContainer.Panel1
            // 
            this.splitContainer.Panel1.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.splitContainer.Panel1.Controls.Add(this._treeView);
            this.splitContainer.Size = new System.Drawing.Size(752, 564);
            this.splitContainer.SplitterDistance = 156;
            this.splitContainer.TabIndex = 3;
            // 
            // _treeView
            // 
            this._treeView.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this._treeView.Dock = System.Windows.Forms.DockStyle.Fill;
            this._treeView.HotTracking = true;
            this._treeView.ImageIndex = 0;
            this._treeView.ImageList = this.ilTreeIcons;
            this._treeView.Location = new System.Drawing.Point(0, 0);
            this._treeView.Margin = new System.Windows.Forms.Padding(4, 3, 4, 3);
            this._treeView.Name = "_treeView";
            this._treeView.SelectedImageIndex = 0;
            this._treeView.Size = new System.Drawing.Size(152, 560);
            this._treeView.TabIndex = 0;
            // 
            // ilTreeIcons
            // 
            this.ilTreeIcons.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("ilTreeIcons.ImageStream")));
            this.ilTreeIcons.TransparentColor = System.Drawing.Color.Transparent;
            this.ilTreeIcons.Images.SetKeyName(0, "bitmap1.bmp");
            this.ilTreeIcons.Images.SetKeyName(1, "bitmap2.bmp");
            this.ilTreeIcons.Images.SetKeyName(2, "bitmap3.bmp");
            this.ilTreeIcons.Images.SetKeyName(3, "bitmap4.bmp");
            this.ilTreeIcons.Images.SetKeyName(4, "bitmap5.bmp");
            this.ilTreeIcons.Images.SetKeyName(5, "bmp00001.bmp");
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(752, 614);
            this.Controls.Add(this.splitContainer);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip;
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "MainForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Untitled - IFCViewer";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.splitContainer.Panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer)).EndInit();
            this.splitContainer.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem openToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.SplitContainer splitContainer;
        private System.Windows.Forms.ToolStripMenuItem viewFacesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewWireFrameToolStripMenuItem;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripMenuItem resetToolStripMenuItem;
        private System.Windows.Forms.TreeView _treeView;
        private System.Windows.Forms.ImageList ilTreeIcons;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripMenuItem selectOnOverIn3DToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutIfcviewerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuSaveAs;
    }
}

