﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// Presentation of an IFC structure as a tree.
    /// </summary>
    class TreeIFCitemView : IFCItemView
    {
        /// <summary>
        /// ctor
        /// </summary>
        public TreeIFCitemView()
            : base()
        {
        }

        /// <summary>
        /// ctor
        /// </summary>
        public TreeIFCitemView(int_t iInstance, IFCItem item)
            : base(iInstance, item)
        {
        }

        /// <summary>
        /// ctor
        /// </summary>
        public TreeIFCitemView(int_t iInstance)
            : base(iInstance)
        {
        }

        /// <summary>
        /// Accessor
        /// </summary>
        public TreeNode Node
        {
            get;
            set;
        }

        /// <summary>
        /// Overridden
        /// </summary>
        public override bool IsVisible
        {
            get
            {
                System.Diagnostics.Debug.Assert(this.Node != null, "Internal error.");

                if ((this.Node.ImageIndex == TreeIFCViewer.IMAGE_CHECKED) || (this.Node.ImageIndex == TreeIFCViewer.IMAGE_MIDDLE))
                {
                    return true;
                }

                return false;
            }
        }
    }
}
