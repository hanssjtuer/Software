﻿using SharpDX;
using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// class responsible to encapsulate an implementation for ray picking for closest object 
    /// </summary>
    class IFCPicker
    {
        private Device _device = null;
        private Vector3 _center = new Vector3();
        private float _size = 0;
        private IFCItem _rootIfcItem = null;

        private double _dist = 0;
        private IFCItem _ifcItemPicked = null;
        Vector3 _rayPos = new Vector3();
        Vector3 _rayDir = new Vector3();

        public IFCPicker(Device device, Vector3 center, float size, IFCItem rootItem)
        {
            _device = device;
            _center = center;
            _size = size;
            _rootIfcItem = rootItem;

        }

        private bool IntersectTri(int_t noPrimitives, int[] indicesForFaces, float[] verticesForFaces, out double minDist)
        {
            minDist = Double.MaxValue;

            Ray ray = new Ray(_rayPos, _rayDir);

            // For each triangle in the item check if it interacts with the ray

            for (int_t i = 0; i < noPrimitives; i++)
            {
                // Get Triangle of the ifcitem

                Vector3 first, second, third;
                first.X = (verticesForFaces[6 * indicesForFaces[3 * i + 0] + 0] - _center.X) / _size;
                first.Y = (verticesForFaces[6 * indicesForFaces[3 * i + 0] + 1] - _center.Y) / _size;
                first.Z = (verticesForFaces[6 * indicesForFaces[3 * i + 0] + 2] - _center.Z) / _size;
                second.X = (verticesForFaces[6 * indicesForFaces[3 * i + 1] + 0] - _center.X) / _size;
                second.Y = (verticesForFaces[6 * indicesForFaces[3 * i + 1] + 1] - _center.Y) / _size;
                second.Z = (verticesForFaces[6 * indicesForFaces[3 * i + 1] + 2] - _center.Z) / _size;
                third.X = (verticesForFaces[6 * indicesForFaces[3 * i + 2] + 0] - _center.X) / _size;
                third.Y = (verticesForFaces[6 * indicesForFaces[3 * i + 2] + 1] - _center.Y) / _size;
                third.Z = (verticesForFaces[6 * indicesForFaces[3 * i + 2] + 2] - _center.Z) / _size;

                float dDistance;
                if (ray.Intersects(ref first, ref second, ref third, out dDistance))
                {
                    if (dDistance < minDist)
                    {
                        minDist = dDistance;
                    }
                }
            }

            if (minDist != Double.MaxValue)
            {
                return true;
            }

            return false;
        }

        private void FindPickedIfcItem(IFCItem ifcItem)
        {
            while (ifcItem != null)
            {
                bool isVisible = (ifcItem.ifcTreeView != null) ? ifcItem.ifcTreeView.IsVisible : true;

                if (isVisible == true)
                {
                    if (ifcItem.TrianglesCount != 0 && ifcItem.verticesCount != 0)
                    {
                        if (ifcItem.vertices != null)
                        {
                            double minDistForIFCItem = Double.MaxValue;

                            if (IntersectTri(ifcItem.TrianglesCount, ifcItem.indicesForFaces, ifcItem.vertices, out minDistForIFCItem))
                            {
                                if (_dist > minDistForIFCItem)
                                {
                                    _dist = minDistForIFCItem;
                                    _ifcItemPicked = ifcItem;
                                }
                            }
                        } // if (ifcItem.verticesForFaces != null )             
                    }
                }

                FindPickedIfcItem(ifcItem.child);

                ifcItem = ifcItem.next;

            } //   if (ifcItem != null)

        }

        // ---------------------------------------------------------------------
        // Implement Picking procedure
        // Notes from here: http://www.toymaker.info/Games/html/picking.html
        public IFCItem PickObject(System.Drawing.Point location)
        {
            // ---------------------------------------------------------------------
            // Transform mouse point to world space point

            Vector3 near = new Vector3(location.X, location.Y, 0f);
            Vector3 far = new Vector3(location.X, location.Y, 1f);

            Matrix worldView = Matrix.Multiply(
               _device.GetTransform(TransformState.World),
               _device.GetTransform(TransformState.View));

            Matrix worldViewProjection = Matrix.Multiply(
                worldView,
                _device.GetTransform(TransformState.Projection));

            near = Vector3.Unproject(near, _device.Viewport.X, _device.Viewport.Y, _device.Viewport.Width, _device.Viewport.Height, _device.Viewport.MinDepth, _device.Viewport.MaxDepth, worldViewProjection);
            far = Vector3.Unproject(far, _device.Viewport.X, _device.Viewport.Y, _device.Viewport.Width, _device.Viewport.Height, _device.Viewport.MinDepth, _device.Viewport.MaxDepth, worldViewProjection);

            // ---------------------------------------------------------------------
            //Transform GUI coordinates to space coordinates

            _rayPos = near;
            _rayDir = far - near;
            _rayDir.Normalize();

            // ---------------------------------------------------------------------
            // clean data in use
            _ifcItemPicked = null;

            _dist = Double.MaxValue;

            FindPickedIfcItem(_rootIfcItem);

            return _ifcItemPicked;
        }
    }
}
