﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// The visual presentation of an IFC item.
    /// </summary>
    class IFCItemView
    {
        /// <summary>
        /// ctor
        /// </summary>
        public IFCItemView()
        {
            this.Instance = -1;
            this.Item = null;
        }

        /// <summary>
        /// ctor
        /// </summary>
        public IFCItemView(int_t iInstance, IFCItem item)
        {
            this.Instance = iInstance;
            this.Item = item;
        }

        /// <summary>
        /// ctor
        /// </summary>
        public IFCItemView(int_t iInstance)
            : this(iInstance, null)
        {
        }

        /// <summary>
        /// Accessor
        /// </summary>
        public int_t Instance
        {
            get;
            private set;
        }

        /// <summary>
        /// Accessor
        /// </summary>
        public IFCItem Item
        {
            get;
            private set;
        }

        /// <summary>
        /// Getter
        /// </summary>
        public virtual bool IsVisible
        {
            get
            {
                return true;
            }
        }
    }
}
