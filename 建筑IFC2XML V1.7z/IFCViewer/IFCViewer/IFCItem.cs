﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

#if _WIN64
using int_t = System.Int64;
#else
using int_t = System.Int32;
#endif

namespace IFCViewer
{
    /// <summary>
    /// An IFC item
    /// </summary>
    class IFCItem
    {
        #region Constants

        /// <summary>
        /// circleSegments()
        /// </summary>
        public const int DEFAULT_CIRCLE_SEGMENTS = 36;

        #endregion // Constants

        public int_t instance = 0;
        public string ifcType;
        public IFCItem parent = null;
        public IFCItem next = null;
        public IFCItem child = null;

        /// <summary>
        /// Vertices for the faces and wireframes
        /// </summary>
        public float[] vertices;

        /// <summary>
        /// Vertices count
        /// </summary>
        public int_t verticesCount;

        /// <summary>
        /// Materials
        /// </summary>
        public STRUCT_MATERIALS materials = null;

        public int[] indicesForFaces;
        public int_t vertexOffsetForFaces;
        public int_t indexOffsetForFaces;
        public int[] indicesForWireFrameLineParts;
        public int_t vertexOffsetForWireFrame;
        public int_t indexOffsetForWireFrame;

        /// <summary>
        /// The first argument for circleSegments()
        /// </summary>
        public int_t circleSegments = DEFAULT_CIRCLE_SEGMENTS;

        /// <summary>
        /// The visual presentation of an IFC item
        /// </summary>
        public IFCItemView ifcTreeView = null;

        /// <summary>
        /// Factory
        /// </summary>
        /// <param name="parent"></param>
        /// <param name="iInstance"></param>
        /// <param name="ifcType"></param>
        public void CreateItem(IFCItem parent, int_t iInstance, string ifcType)
        {
            this.parent = parent;
            this.next = null;
            this.child = null;
            this.instance = iInstance;
            this.ifcType = ifcType;

            if (parent != null)
            {
                if (parent.child == null)
                {
                    parent.child = this;
                }
                else
                {
                    IFCItem NextChild = parent;

                    while (true)
                    {
                        if (NextChild.next == null)
                        {
                            NextChild.next = this;
                            break;
                        }
                        else
                        {
                            NextChild = NextChild.next;
                        }

                    }

                }

            }
        }

        /// <summary>
        /// The number of the primitives
        /// </summary>
        public int TrianglesCount
        {
            get
            {
                if (indicesForFaces != null)
                {
                    return indicesForFaces.Length / 3;
                }

                return 0;
            }
        }

        /// <summary>
        /// The number of the primitives
        /// </summary>
        public int LinesCount
        {
            get
            {
                if (indicesForFaces != null)
                {
                    return indicesForWireFrameLineParts.Length / 2;
                }

                return 0;
            }
        }
    }
}
