import pandas
import requests
import json

def 公交路线规划(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_):
    公交时间数组 = []
    公交路线规划接口 = 'https://api.map.baidu.com/direction/v2/transit?origin=%s,%s&destination=%s,%s&ak=%s'%(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_)
    # print(公交路线规划接口)
    访问接口 = requests.get(公交路线规划接口)
    访问接口结果 = 访问接口.text
    返回结果 = json.loads(访问接口结果)['result']
    全部路线 = 返回结果['routes']
    for i in 全部路线:
        公交时间 = i['duration']
        公交时间数组.append(公交时间)
    最小公交时间 = min(公交时间数组)
    return 最小公交时间

def 驾车路线规划(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_):
    驾车时间数组 = []
    驾车路线规划接口 = 'https://api.map.baidu.com/directionlite/v1/driving?origin=%s,%s&destination=%s,%s&ak=%s'%(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_)
    # print(驾车路线规划接口)
    访问接口 = requests.get(驾车路线规划接口)
    访问接口结果 = 访问接口.text
    返回结果 = json.loads(访问接口结果)['result']
    全部路线 = 返回结果['routes']
    for i in 全部路线:
        驾车时间 = i['duration']
        驾车时间数组.append(驾车时间)
    最小驾车时间 = min(驾车时间数组)
    return 最小驾车时间


终点文件名称 = '终点.xls'
终点文件内容 = pandas.read_excel(终点文件名称)
终点纬度数组 = 终点文件内容['WGS84_纬度']
终点经度数组 = 终点文件内容['WGS84_经度']
终点个数 = len(终点纬度数组)

起点纬度数组 = [31.03]
起点经度数组 = [121.22]
起点个数 = len(起点纬度数组)

访问应用_AK_ = 'ugGYWun8AdZEhvuj9dc89TFYmpjNVzH4'

for i in range(0, 起点个数):
    for j in range(0, 终点个数):
        起点纬度 = 起点纬度数组[i]
        起点经度 = 起点经度数组[i]
        终点纬度 = 终点纬度数组[j]
        终点经度 = 终点经度数组[j]
        最小公交时间 = 公交路线规划(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_)
        最小驾车时间 = 驾车路线规划(起点纬度, 起点经度, 终点纬度, 终点经度, 访问应用_AK_)
        print('公交最少需要', 最小公交时间, '秒')
        print('驾车最少需要', 最小驾车时间, '秒')

