﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq; // 引用函数式编程，批量操作列表
using System.Text.RegularExpressions; // 引用正则表达式，获取三角面顶点数据
using GeometryGym.Ifc; // 引用IFC文件生成动态链接库
using Coord3d = System.Tuple<double, double, double>; // 自定义三维空间点
using CoordIndex = System.Tuple<int, int, int>; // 自定义三维空间点序列

namespace STL2IFC
{
    class Program
    {
        public static unsafe string BinarySTL2ASCII(string STLFilePath) // 声明BinarySTL2ASCII函数，读取二进制STL文件
        {
            // 使用unsafe关键字，操作指针
            // STL二进制文件大小（字节） = 50 * 三角面个数 + 84 （字节）
            // STL二进制文件大小（KB） = （50 * 三角面个数 + 84）/ 1024 （KB）
            FileStream STLFileStream = new FileStream(STLFilePath, FileMode.Open); // 获取STL文件流
            byte[] STLFileStringBytes = new byte[STLFileStream.Length];  // 声明空列表
            STLFileStream.Read(STLFileStringBytes, 0, STLFileStringBytes.Length); // 读取STL文件流 
            STLFileStream.Close(); // 关闭STL文件流
            string STLFileString = ""; // 声明空字符串
            fixed (byte* b = STLFileStringBytes) // 设置指针
            {
                int* p = (int*)(b + 80); // 文件头存储文件名：1字节-80字节
                int count = *p; // 三角面数量：81字节-84字节
                STLFileString = "三角面数量:" + count.ToString(); // 记录三角面数量
                for (int i = 0; i < count; i++) // 进入循环体，依次打印三角面信息
                {
                    STLFileString += "\r\n" + "第" + (i + 1).ToString() + "个三角面"; // 记录三角面序号
                    STLFileString += "\r\n" + "法向量="; // 记录三角面法向量
                    float* f = (float*)(b + 84 + (50 * i)); // 三角面信息：1个三角面50个字节
                    STLFileString += (*f).ToString(); // 记录三角面法向量x
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面法向量y
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面法向量z
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "\r\n" + "顶点1="; // 记录三角面第一个顶点
                    STLFileString += (*f).ToString(); // 记录三角面第一个顶点x
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第一个顶点y
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第一个顶点z
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "\r\n" + "顶点2="; // 记录三角面第二个顶点
                    STLFileString += (*f).ToString(); // 记录三角面第二个顶点x
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第二个顶点y
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第二个顶点z
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "\r\n" + "顶点3="; // 记录三角面第三个顶点
                    STLFileString += (*f).ToString(); // 记录三角面第三个顶点x
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第三个顶点y
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "," + (*f).ToString(); // 记录三角面第三个顶点z
                    f++; // 移动字节，1个4字节浮点数
                    STLFileString += "\r\n" + "三角面标记="; // 记录三角面属性
                    short* s = (short*)f; // 移动字节，1个2字节整数
                    STLFileString += (*s).ToString(); // 记录三角面属性值
                }
            }
            return STLFileString; // 返回ASCII文本字符串
        }
        public static IfcShapeRepresentation IFCFROMSTL(string STLFileString, DatabaseIfc Di) // 声明IFCFROMSTL函数，生成IFC三角面模型
        {
            List<Coord3d> STL = new List<Coord3d>() { }; // 声明STL三角面全部顶点
            MatchCollection STLMatchResults = null; // 声明正则表达式匹配结果
            Regex STLRegex = new Regex(@"顶点[0-9]+=(.*)\r\n"); // 声明正则表达式匹配模式
            STLMatchResults = STLRegex.Matches(STLFileString); // 获取匹配结果
            foreach (Match i in STLMatchResults)
            {
                // Console.WriteLine(i.Groups[1]); // 测试
                // 引用函数式编程
                double[] STLXYZ = i.Groups[1].Value.Split(',').Select(k => Convert.ToDouble(k)).ToArray(); // 根据逗号进行分割，获取x坐标、y坐标、z坐标
                Coord3d STLPoint = new Coord3d(STLXYZ[0], STLXYZ[1], STLXYZ[2]); // 建立三维坐标点
                STL.Add(STLPoint); // 扩充点集
            }
            IfcCartesianPointList3D Icpl3D = new IfcCartesianPointList3D(Di, STL); // 声明IfcCartesianPointList3D
            List<CoordIndex> Lci = new List<CoordIndex>() { }; // 声明STL三角面全部顶点索引
            // Console.WriteLine("顶点数量：{0}", STL.Count);
            for (int j = 0; j < (int)(STL.Count / 3); j++) // 强制类型转换，进入循环体
            {
                CoordIndex STLIndex = new CoordIndex(j * 3 + 1, j * 3 + 2, j * 3 + 3); // 建立三维坐标点索引
                Lci.Add(STLIndex); // 扩充索引集
            }
            IfcTriangulatedFaceSet Itfs = new IfcTriangulatedFaceSet(Icpl3D, Lci); // 建立点集和索引集的对应
            IfcShapeRepresentation ISR = new IfcShapeRepresentation(Itfs); // 声明IfcShapeRepresentation
            return ISR; // 返回ShapeRepresentation
        }
        static void Main(string[] args)
        {
            string STLFileName = "example.stl"; // 声明STL文件名称（相对路径）
            string STLFileString = BinarySTL2ASCII(STLFileName); // 调用BinarySTL2ASCII函数
            // Console.WriteLine(STLFileString); // 测试，打印ASCII文本字符串
            Console.WriteLine("Binary-{0}转换为ASCII---{0}", STLFileName);
            string IFCFileName = STLFileName.Replace("stl", "ifc"); // 声明IFC文件名称（相对路径）
            DatabaseIfc Di = new DatabaseIfc(ModelView.Ifc4DesignTransfer); // 建立IFC数据库
            IfcProject Ip = new IfcProject(Di, "Project"); // 建立IfcProject
            IfcUnitAssignment Iua = new IfcUnitAssignment(Di, IfcUnitAssignment.Length.Millimetre); // 声明长度单位mm
            Ip.UnitsInContext = Iua; // 声明IfcProject单位
            IfcSite Is = new IfcSite(Di, "Site"); // 建立IfcSite
            IfcBuilding Ib = new IfcBuilding(Di, "Building"); // 声明IfcBuilding
            IfcBuildingStorey Ibs = new IfcBuildingStorey(Ib, "BuildingStorey", 0.00); // 声明IfcBuildingStorey
            Ip.AddAggregated(Is); // 添加附属关系（Project---Site）
            Is.AddAggregated(Ib); // 添加附属关系（Site---Building）
            IfcShapeRepresentation Isr = IFCFROMSTL(STLFileString, Di); // 调用IFCFROMSTL函数
            IfcProductDefinitionShape Ipds = new IfcProductDefinitionShape(Isr); // 声明IfcProductDefinitionShape
            new IfcBuildingElementProxy(Ibs, Ibs.ObjectPlacement, Ipds); // 添加附属关系（BuildingStorey---BuildingElementProxy）
            Di.WriteFile(IFCFileName); // 生成IFC文件
            Console.WriteLine("{0}转换为{1}", STLFileName, IFCFileName);
            Console.ReadKey(); // 暂留打印信息
        }
    }
}
