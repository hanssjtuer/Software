# 读取文件
import pandas
Sheet1Data = pandas.read_excel('元素.xls', sheet_name = 'Sheet1', header=None)
keyword = list(Sheet1Data.iloc[1])[2:52:1]
SetIndex = list(Sheet1Data.iloc[0])[2:52:1]
SetIndex = [str(i) for i in SetIndex]
connection = dict()

import re
from graphviz import Digraph
global MyGraph
MyGraph = Digraph(filename='ISM.gv', format='svg', node_attr={'shape':'circle', 'fixedsize':'true', 'width':'1', 'height':'1'})
for i in range(2, 52, 1):
    row = list(Sheet1Data.iloc[i])[2:52:1]
    value = []
    for j in range(0, 50, 1):
        if row[j] == 1:
            value.append(keyword[j])
    key = keyword[i-2]
    key1 = key.replace(' ', '\n')
    MyGraph.node(key, key1, style='filled', color='yellow')
    connection[key] = value
print(connection)
dictionary = dict(zip(SetIndex, keyword))
Sheet1Data = Sheet1Data.iloc[2:52, 2:52]

# 邻接矩阵
import numpy
data = numpy.array(Sheet1Data)
AdjacencyMatrix = numpy.matrix(data)
print("邻接矩阵：%s"%AdjacencyMatrix)

# 可达矩阵
AccessibilityMatrix = None
import numpy.matlib
dimension = len(AdjacencyMatrix)
IdentityMatrix = numpy.matlib.identity(len(AdjacencyMatrix))
APlusI = AdjacencyMatrix + IdentityMatrix
condition = True
while condition:
    temp = APlusI
    APlusI = temp * APlusI
    APlusI[APlusI > 1] = 1
    if (temp == APlusI).all():
        condition = False
        AccessibilityMatrix = pandas.DataFrame(APlusI, dtype=int)
        AccessibilityMatrix.to_excel('可达矩阵.xls', sheet_name='Sheet2')
print("可达矩阵：%s"%AccessibilityMatrix)

# 可达集合
ReachAbilitySet = dict()
for i in range(0, 50, 1):
    row = list(AccessibilityMatrix.iloc[i])[0:50:1]
    value = []
    for j in range(0, 50, 1):
        if row[j] == 1:
            value.append(str(SetIndex[j]))
    ReachAbilitySet[str(i+1)] = value
print("可达集合：%s"%ReachAbilitySet)

# 先行集合
AntecedentSet = dict()
for i in range(0, 50, 1):
    column = list(AccessibilityMatrix.iloc[:, i])[0:50:1]
    value = []
    for j in range(0, 50, 1):
        if column[j] == 1:
            value.append(str(SetIndex[j]))
    AntecedentSet[str(i+1)] = value
print("先行集合：%s"%AntecedentSet)

# 共同集合
CommonSet = dict()
for key, value in ReachAbilitySet.items():
	intersection = set(value).intersection(set(AntecedentSet[key]))
	CommonSet[key] = list(intersection)
print("共同集合：%s"%CommonSet)

# 开始集合
BeginningSet = []
for key, value in AntecedentSet.items():
	if value == CommonSet[key]:
		BeginningSet.append(key)
print("开始集合：%s"%BeginningSet)

# 终止集合
EndSet = []
for key, value in ReachAbilitySet.items():
	if value == CommonSet[key]:
		EndSet.append(key)
print("终止集合：%s"%EndSet)

# 分区 + 分级 + 多级递阶有向图
def cycle(connection):
	result = []
	for key, value in connection.items():
	    for key1, value1 in connection.items():
	        if key != key1:
	            if key in value1:
	                if  key1 in value:
	                    result.append([key, key1])
	return result

def graph(connection, MyGraph, StrongConnection):
    for key, value in connection.items():
        for i in value:
            if [i, key] not in StrongConnection:
                MyGraph.edge(key, i)
    for i in StrongConnection:
        MyGraph.edge(i[0], i[1])

if len(BeginningSet) == 1:
	StrongConnection = cycle(connection)
	graph(connection, MyGraph, StrongConnection)
	MyGraph.view()
else:
	for i in BeginningSet:
		length = 0
		for j in BeginningSet:
			if i != j:
				intersection = set(ReachAbilitySet[i]).intersection(set(ReachAbilitySet[j]))
				length = length + len(list(intersection))
		if length == 0:
			connection1 = dict()
			keys = ReachAbilitySet[i]
			keys1 = [dictionary[a] for a in keys]
			for key, value in connection.items():
				if key in keys1:
					connection1[key] = value
			StrongConnection = cycle(connection1)
			graph(connection1, MyGraph, StrongConnection)
	MyGraph.view()
