from gurobipy import * # 导入Gurobi模块的全部类
try: # 执行可能产生异常的代码块
    m = Model("production&transportation") # 声明模型
    demand = [110, 160, 80, 200, 100] # 定义n个城市的需求
    capacity = [min(140/0.8, 220), min(200/0.8, 380), min(240/0.8, 250), min(360/0.8, 400)] # 定义m个工厂的容量
    transCosts = [[8, 13, 12, 3, 14], [10, 6, 7, 3, 9], [4, 9, 6, 5, 4], [7, 5, 9, 12, 10]] # 定义m个工厂到n个城市的运输费用
    prodCosts = [1, 1, 1, 1] # 定义m个工厂的产品成本
    plants = range(len(capacity)) # 获取工厂数量
    cities = range(len(demand)) # 获取城市数量
    production = m.addVars(plants, vtype=GRB.CONTINUOUS, obj=prodCosts, ub=capacity, name="production") # 批量声明实数变量（m个工厂的产量）
    transport = m.addVars(plants, cities, vtype=GRB.CONTINUOUS, obj=transCosts, name="trans") # 批量声明实数变量（m个工厂到n个城市的运输量）
    m.modelSense = GRB.MINIMIZE #设置目标函数min（最小总运输费用）
    m.addConstrs((transport.sum(p) == production[p] for p in plants), "Capacity") # 批量添加不等式约束条件（每个工厂的总运输量不超出工厂的容量）
    m.addConstrs((transport.sum('*',c) == demand[c] for c in cities),"Demand") # 批量添加不等式约束条件（每个城市的总运输量不超出城市的需求）
    m.optimize() # 求解模型
    for v in m.getVars(): # 进入循环体
        print(v.varName, v.x) # 获取变量名和变量的解
    print('Obj',m.objVal) # 获取目标函数值
except GurobiError: # 执行处理异常的代码块
    print('Error') # 打印提示信息