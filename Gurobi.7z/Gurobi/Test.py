from gurobipy import * # 导入Gurobi模块的全部类
try: # 执行可能产生异常的代码块
    m = Model('model name') # 声明模型
except GutobiError: # 执行处理异常的代码块
    print('Error reported') # 打印提示信息