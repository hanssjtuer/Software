from gurobipy import * # 导入Gurobi模块的全部类
try: # 执行可能产生异常的代码块
    m = Model('lp') # 声明模型
    x = m.addVar(vtype=GRB.BINARY, name='x') # 声明01变量x
    y = m.addVar(vtype=GRB.BINARY, name='y') # 声明01变量y
    z = m.addVar(vtype=GRB.BINARY, name='z') # 声明01变量z
    m.setObjective(x + y + 2 * z, GRB.MAXIMIZE)  #设置目标函数max
    m.addConstr(x + 2 * y + 3 * z <= 4) # 添加不等式约束条件1
    m.addConstr(x + y >= 1) # 添加不等式约束条件2
    m.optimize() # 求解模型
    for v in m.getVars(): # 进入循环体
        print(v.varName, v.x) # 获取变量名和变量的解
    print('Obj',m.objVal) # 获取目标函数值
except GurobiError: # 执行处理异常的代码块
    print('Error') # 打印提示信息