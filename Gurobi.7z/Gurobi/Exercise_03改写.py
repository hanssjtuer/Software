import gurobipy as gp # 导入Gurobi模块
from gurobipy import GRB # 导入Gurobi模块的GRB类
# 定义函数，获取变量名和变量的解，获取目标函数值
def printSolution():
    if m.status == GRB.OPTIMAL: # 判断有解
        print('\nCost: %g' % m.ObjVal) # 获取总成本，进行字符串格式化打印
        print('\nBuy:') # 进入循环体，获取食物和食物数量
        for f in foods:
            if buy[f].X > 0.0001: # 设置食物数量阈值
                print('%s %g' % (f, buy[f].X)) # 获取食物和食物数量，进行字符串格式化打印
    else: # 判断无解
        print('No solution') # 打印提示信息
# 定义键值对，键（字符串）为营养成分，值（数组）为营养成分含量取值范围
categories, minNutrition, maxNutrition = gp.multidict({
'calories': [1800, 2200],
'protein': [91, GRB.INFINITY], # 蛋白质含量取值上限为正无穷
'fat': [0, 65],
'sodium': [0, 1779]})
# 定义键值对，键（字符串）为食物，值（浮点数）为食物价格
foods, cost = gp.multidict({
'hamburger': 2.49,
'chicken': 2.89,
'hot dog': 1.50,
'fries': 1.89,
'macaroni': 2.09,
'pizza': 1.99,
'salad': 2.49,
'milk': 0.89,
'ice cream': 1.59})
# 定义键值对，键（元组）为食物及其营养成分，值（浮点数）为营养成分含量
nutritionValues = { 
# hamburger及其营养成分含量
('hamburger', 'calories'): 410,
('hamburger', 'protein'): 24,
('hamburger', 'fat'): 26, 
('hamburger', 'sodium'): 730, 

# chicken及其营养成分含量
('chicken', 'calories'): 420, 
('chicken', 'protein'): 32, 
('chicken', 'fat'): 10, 
('chicken', 'sodium'): 1190, 

# hot dog及其营养成分含量
('hot dog', 'calories'): 560, 
('hot dog', 'protein'): 20, 
('hot dog', 'fat'): 32, 
('hot dog', 'sodium'): 1800, 

# fires及其营养成分含量
('fries', 'calories'): 380, 
('fries', 'protein'): 4,
('fries', 'fat'): 19, 
('fries', 'sodium'): 270, 

# macaroni及其营养成分含量
('macaroni', 'calories'): 320, 
('macaroni', 'protein'): 12, 
('macaroni', 'fat'): 10, 
('macaroni', 'sodium'): 930, 

# pizza及其营养成分含量
('pizza', 'calories'): 320, 
('pizza', 'protein'): 15, 
('pizza', 'fat'): 12, 
('pizza', 'sodium'): 820, 

# salad及其营养成分含量
('salad', 'calories'): 320, 
('salad', 'protein'): 31, 
('salad', 'fat'): 12, 
('salad', 'sodium'): 1230, 

# milk及其营养成分含量
('milk', 'calories'): 100, 
('milk', 'protein'): 8, 
('milk', 'fat'): 2.5, 
('milk', 'sodium'): 125, 

# ice cream及其营养成分含量
('ice cream', 'calories'): 330, 
('ice cream', 'protein'): 8, 
('ice cream', 'fat'): 10,
('ice cream', 'sodium'): 180}

m = gp.Model("diet") # 声明模型
# buy = m.addVars(foods, name="buy") # 批量声明变量（原来）

###########################################################################改写buy
buy = {}
for f in foods:
    buy[f] = m.addVar(name=f)
###########################################################################改写buy

# m.setObjective(buy.prod(cost), GRB.MINIMIZE) #设置目标函数min（原来）

###########################################################################改写目标函数
m.setObjective(sum(buy[f]*cost[f] for f in foods), GRB.MINIMIZE)
###########################################################################改写目标函数

# m.addConstrs((gp.quicksum(nutritionValues[f, c] * buy[f] for f in foods)
# == [minNutrition[c], maxNutrition[c]] for c in categories), "_") # 批量添加不等式约束条件（原来）

###########################################################################改写约束条件
for c in categories:
    m.addRange(sum(nutritionValues[f, c] * buy[f] for f in foods),
        minNutrition[c], maxNutrition[c], c)
###########################################################################改写约束条件

m.optimize() # 求解模型
printSolution() # 执行printSolution函数

print('\nAdding constraint: at most 6 servings of dairy') # 添加额外不等式约束条件
# m.addConstr(buy.sum(['milk', 'ice cream']) <= 6, "limit_dairy") # 限制milk的数量

###########################################################################改写额外约束条件
# 改写buy时，导致buy的数据类型由原来的<gurobipy.tupledict>变为现在的<dict>，而<dict>类型没有sum属性，故报错，因而需要改写
# 使用强制类型转换tupledict()
from gurobipy import tupledict
m.addConstr(tupledict(buy).sum(['milk', 'ice cream']) <= 6, "limit_dairy") # 限制milk的数量
###########################################################################改写额外约束条件

m.optimize() # 再次求解模型
printSolution() # 再次执行printSolution函数