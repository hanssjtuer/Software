from gurobipy import * # 导入Gurobi模块的全部类
try: # 执行可能产生异常的代码块
    m = Model('lp') # 声明模型
    x = m.addVar(vtype=GRB.CONTINUOUS, name='x') # 声明实数变量x
    y = m.addVar(vtype=GRB.CONTINUOUS, name='y') # 声明实数变量y
    z = m.addVar(vtype=GRB.CONTINUOUS, name='z') # 声明实数变量z
    k = m.addVar(vtype=GRB.CONTINUOUS, name='k') # 声明实数变量k
    m.setObjective(-3 * x + y + 3 * z - k, GRB.MINIMIZE) # 设置目标函数min
    m.addConstr(x + 2 * y - z + k == 0) # 添加等式约束条件1
    m.addConstr(2 * x - 2 * y + 3 * z + 3 * k == 9) # 添加等式约束条件2
    m.addConstr(x - y + 2 * z - k == 6) # 添加等式约束条件3
    m.addConstr(x >= 0) # x非负
    m.addConstr(y >= 0) # y非负
    m.addConstr(z >= 0) # z非负
    m.addConstr(k >= 0) # k非负
    m.optimize() # 求解模型
    for v in m.getVars(): # 进入循环体
        print(v.varName, v.x) # 获取变量名和变量的解
    print('Obj', m.objVal) # 获取目标函数值
except GurobiError: # 执行处理异常的代码块
    print('Error') # 打印提示信息